
#pragma once

#include <map>
#include <iostream>
#include <queue>
#include <map>
#include <array>
#include <climits>
#include <iterator>
#include <algorithm>
#include <type_traits>
#include <numeric>
#include <iostream>
#include <opencv2/opencv.hpp>